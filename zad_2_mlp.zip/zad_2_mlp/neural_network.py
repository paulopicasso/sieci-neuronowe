import numpy as np
from typing import Callable, List
from neuron_layer import NeuronLayer
import helpers
from logger import logD, logM

class NeuralNetwork:

    def __init__(
        self,
        layerSizes: List[int],
        inputSize: int,
        outputSize: int,
        minWeight: float,
        maxWeight: float,
        minBias: float,
        maxBias: float,
        activationFunc: Callable[[np.ndarray], np.ndarray]
    ):
        self.layers = [
            NeuronLayer(
                size,
                inputSize if i == 0 else layerSizes[i - 1],
                minWeight,
                maxWeight,
                minBias,
                maxBias,
                activationFunc
            )
            for i, size in enumerate(layerSizes)
        ] + [NeuronLayer(outputSize, layerSizes[-1], minWeight, maxWeight, minBias, maxBias, helpers.softmax)]
        self.debugBatch = 0


    def getAnswer(self, input: np.ndarray) -> int:
        output = self.feedForward(input)
        return np.argmax(output)


    def feedForward(self, input: np.ndarray) -> np.ndarray:
        currentIntput = input

        for layer in self.layers:
            output = layer.processInput(currentIntput)
            currentIntput = output

        return currentIntput


    def backPropagateError(self, output: np.ndarray, expectedOutput: np.ndarray):
        lastLayer = self.layers[-1]
        lastLayerError = expectedOutput - output
        lastLayer.errors.append(lastLayerError)

        for i, layer in helpers.reverseEnumerate(self.layers[:-1]):
            nextLayer = self.layers[i + 1]
            derivFunction = helpers.resolveDerivative(layer.activationFunc)
            layerError = (nextLayer.weights.T @ nextLayer.errors[-1]) * derivFunction(layer.netValues)
            layer.errors.append(layerError)

    
    def updateWeights(self, alpha: float, batch: np.array):
        batchSize = np.size(batch, 0)

        for i, layer in helpers.reverseEnumerate(self.layers):
            activations = self.layers[i - 1].activations if i > 0 else batch
            errors = layer.errors
            delta = np.sum([
                np.reshape(errors[j], (1, -1)).T @ np.reshape(activations[j], (1, -1))
                for j in range(batchSize)
            ], 0)
            logD('layer: ', i)
            logD(delta)
            layer.weights = layer.weights - (alpha / batchSize) * delta
            layer.biases = layer.biases - (alpha / batchSize) * np.sum(errors, 0)


    def clearLayers(self):
        for layer in self.layers:
            layer.clear()


    def validateModel(self, inputs: np.ndarray, expectedOutputs: np.ndarray) -> float:
        outputs = [self.feedForward(input) for input in inputs]
        results = [self.getAnswer(input) for input in inputs]
        errors = np.array([
            helpers.crossEntropy(output, expectedOutput) 
            for output, expectedOutput in zip(outputs, expectedOutputs)
        ])
        correctness = 0
        for i, result in enumerate(results):
            if(expectedOutputs[i][result] == 1):
                correctness = correctness + 1
        logM('Correct: ', correctness, '/', np.size(expectedOutputs, 0))
        return np.average(errors)


    def learn(
        self,
        inputs: np.ndarray,
        expectedOutputs: np.ndarray,
        batchSize: int,
        alpha: float,
        validationInputs: np.ndarray,
        validationOutputs: np.ndarray,
        desiredError: float
    ):

        error = desiredError
        while error >= desiredError: # Epoch

            batchIndex = 0
            while batchIndex + batchSize <= np.size(inputs, 0): # Iterating batches
                self.debugBatch = self.debugBatch + 1

                nextBatchIndex = batchIndex + batchSize
                batch = inputs[batchIndex:nextBatchIndex]
                for i, inputRow in enumerate(batch): # Processing one batch
                    output = self.feedForward(inputRow)
                    expectedOutput = expectedOutputs[batchIndex + i]
                    self.backPropagateError(output, expectedOutput)
                    
                self.updateWeights(alpha, batch)
                # logM(self.layers[1].weights.flatten())
                error = self.validateModel(validationInputs, validationOutputs)
                self.clearLayers()
                logM('Error: ', error)
                batchIndex = nextBatchIndex
                

