QUIET = 0
MESSAGE = 1
DEBUG = 2

logLevel = MESSAGE


def logM(*messages: str):
    if(logLevel >= MESSAGE):
        print(*messages)


def logD(*messages: str):
    if(logLevel >= DEBUG):
        print(*messages)