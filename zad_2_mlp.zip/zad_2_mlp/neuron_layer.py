import numpy as np
from typing import Callable

class NeuronLayer:

    def __init__(
        self,
        size: int,
        inputSize: int,
        minWeight: float,
        maxWeight: float,
        minBias: float,
        maxBias: float,
        activationFunc: Callable[[np.ndarray], np.ndarray],
    ):
        self.weights = self.initializeWeights(size, inputSize, minWeight, maxWeight)
        self.biases = self.initializeBiases(size, minBias, maxBias)
        self.activationFunc = activationFunc
        self.netValues = np.array([]) # 1 x number_of_neurons
        self.activations = [] # samples_in_batch x number_of_neurons
        self.errors = [] # samples_in_batch x number_of_neurons


    def initializeBiases(self, size: int, min: float, max: float) -> np.ndarray:
        baseBiases = np.random.rand(size)
        return baseBiases * (max - min) + min


    def initializeWeights(self, size: int, inputSize: int, min: float, max: float) -> np.ndarray:
        baseWeights = np.random.rand(size, inputSize)
        return baseWeights * (max - min) + min


    def processInput(self, input: np.ndarray) -> np.ndarray:
        net = (self.weights @ input) + self.biases
        activation = self.activationFunc(net)
        self.netValues = net
        self.activations.append(activation)

        return activation


    def clear(self):
        self.netValues = np.array([])
        self.activations = []
        self.errors = []