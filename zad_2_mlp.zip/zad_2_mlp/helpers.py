from math import e
import numpy as np
from typing import Callable 

def sigmoid(input: np.ndarray) -> np.ndarray:
    input64 = np.array(input, dtype='f8')
    return np.array([1 / (1 + e**float(-x)) for x in input64], dtype='f8')

def tanh(input: np.ndarray) -> np.ndarray:
    input64 = np.array(input, dtype='f8')
    return np.array([(2 / (1 + e**(-2*float(x)))) - 1 for x in input64], dtype='f8')

def softmax(input: np.ndarray) -> np.ndarray:
    input64 = np.array(input, dtype='f8')
    exp = e ** input64
    return exp / np.sum(exp)

def crossEntropy(output: np.ndarray, expectedOutput: np.ndarray) -> float:
    length = np.size(output, 0)
    return (-1/length) * np.sum(expectedOutput * np.log(output))

def sigmoidDeriv(input: np.ndarray) -> np.ndarray:
    input64 = np.array(input, dtype='f8')
    sigmoidOutput = sigmoid(input64)
    return sigmoidOutput * (1 - sigmoidOutput)

def resolveDerivative(activationFunc: Callable[[np.ndarray], np.ndarray]) -> Callable[[np.ndarray], np.ndarray]:
    if(activationFunc == sigmoid):
        return sigmoidDeriv
    return sigmoidDeriv

def reverseEnumerate(array):
    return reversed(list(enumerate(array)))

def appendVector(originArray: np.ndarray, appendage: np.ndarray) -> np.ndarray:
    return np.append(originArray, np.reshape(appendage, (1, -1)), 0)
