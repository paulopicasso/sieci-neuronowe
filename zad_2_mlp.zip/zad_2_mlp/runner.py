from neural_network import NeuralNetwork
import numpy as np
import data_loader
import helpers

def teachNeuralNetwork(
    network: NeuralNetwork,
    batchSize: int,
    alpha: float,
    desiredError: float,
    validationSetSize: int
):
    inputs = data_loader.loadTrainInputs()
    outputs = data_loader.loadTrainOutputs()
    dataSize = np.size(inputs, 0)
    trainInputs = inputs[0:-validationSetSize]
    trainOutputs = outputs[0:-validationSetSize]
    validationInputs = inputs[-validationSetSize:dataSize]
    validationOutputs = outputs[-validationSetSize:dataSize]

    network.learn(
        trainInputs,
        trainOutputs,
        batchSize,
        alpha,
        validationInputs,
        validationOutputs,
        desiredError
    )


def main():
    network = NeuralNetwork(
        [28],
        28 * 28,
        10,
        1, 1,
        1, 1,
        helpers.sigmoid
    )
    teachNeuralNetwork(
        network,
        20,
        0.1,
        0.001,
        10 * 1000
    )


main()